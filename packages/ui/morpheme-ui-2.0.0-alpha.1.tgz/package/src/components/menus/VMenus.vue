<script setup lang="ts">
import {computed, defineAsyncComponent} from 'vue';
import Icon from '@morpheme/icon';
import VMenusItem from './VMenusItem.vue';
import type {Placement} from '@floating-ui/vue';

export type VMenuItem = InstanceType<typeof VMenusItem>['$props'] & {
  children?: VMenuItem[];
};

export interface Props {
  items?: VMenuItem[];
  right?: boolean;
  /**
   * @deprecated
   */
  rightIcon?: string;
  small?: boolean;
  btnClass?: string;
  placement?: Placement;
  label?: string;
  hover?: boolean;
  btnIcon?: string;
  btnIconClass?: string;
  itemClass?: string;
  itemsClass?: string;
  itemsStyle?: Record<string, any>;
  theme?: string;
  iconSize?: string;
  child?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  items: () => [],
  right: false,
  rightIcon: 'ri:arrow-down-s-line',
  small: false,
  btnClass: '',
  placement: 'bottom-start',
  label: 'Menu',
  hover: false,
  btnIcon: 'ri:arrow-down-s-line',
  btnIconClass: '',
  itemClass: '',
  itemsClass: '',
  itemsStyle: () => ({}),
  theme: 'menus',
  iconSize: 'sm',
});

// Import floating-vue components only on client side
const Menu = defineAsyncComponent(async () => {
  if (typeof window === 'undefined') {
    return {
      name: 'MenuSSR',
      template: '<div><slot /><slot name="popper" /></div>'
    };
  }
  const { Menu } = await import('floating-vue');
  return Menu;
});

const Dropdown = defineAsyncComponent(async () => {
  if (typeof window === 'undefined') {
    return {
      name: 'DropdownSSR',
      template: '<div><slot /><slot name="popper" /></div>'
    };
  }
  const { Dropdown } = await import('floating-vue');
  return Dropdown;
});

// Configure floating-vue theme only on client side
if (typeof window !== 'undefined') {
  import('floating-vue').then(({ default: FloatingVue }) => {
    FloatingVue.options.themes.menus = {
      $extend: 'dropdown',
      $resetCss: false,
    };
  });
}

const menuPlacement = computed(() => {
  return props.right ? 'bottom-end' : props.placement;
});

defineSlots<{
  default?: (props: {
    shown: boolean;
    show: () => void;
    hide: () => void;
  }) => any;
  items?: (props: {}) => any;
}>();
</script>

<template>
  <component
    :is="hover ? Menu : Dropdown"
    :placement="menuPlacement"
    class="v-menus"
    :class="{
      'v-menus--child': child,
      'v-menus--right': right,
      'v-menus--small': small,
    }"
    popper-class="v-menus-popper"
    theme="menus"
    :triggers="hover ? ['hover'] : ['click']"
    :autoHide="true"
  >
    <template #default="{shown, show, hide}">
      <slot v-bind="{shown, show, hide}">
        <button
          :class="['v-menus-button', btnClass]"
          :aria-label="label"
          type="button"
        >
          {{ label }}
          <Icon
            :name="btnIcon"
            :size="iconSize"
            class="v-menus-button-icon"
            :class="[btnIconClass, {'v-menus-button-icon--active': shown}]"
          />
        </button>
      </slot>
    </template>
    <template #popper>
      <div class="v-menus-items" :class="itemsClass" :style="itemsStyle">
        <slot name="items">
          <template v-for="item in items" :key="item.text">
            <VMenus
              v-if="item.children"
              :items="item.children"
              placement="right-start"
              child
            >
              <VMenusItem
                :class="itemClass"
                v-bind="item"
                :small="item.small || small"
                append-icon="ri:arrow-right-s-line"
              />
            </VMenus>
            <VMenusItem
              v-else
              :class="itemClass"
              v-bind="item"
              :small="item.small || small"
            />
          </template>
        </slot>
      </div>
    </template>
  </component>
</template>
